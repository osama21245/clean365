<?php

return [
    'name' => 'BookingModule'
];
