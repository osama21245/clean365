<?php

return [
    'name' => 'BlogModule',
];
