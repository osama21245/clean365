<?php

return [
    'name' => 'AI'];
