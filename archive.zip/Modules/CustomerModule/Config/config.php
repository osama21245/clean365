<?php

return [
    'name' => 'CustomerModule'
];
