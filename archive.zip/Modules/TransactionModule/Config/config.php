<?php

return [
    'name' => 'TransactionModule'
];
